"""Tests for Panopto Downloader."""

